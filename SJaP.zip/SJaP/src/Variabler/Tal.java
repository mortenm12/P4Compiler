package Variabler;


public class Tal extends Var{
	public Double typeVal;
}
