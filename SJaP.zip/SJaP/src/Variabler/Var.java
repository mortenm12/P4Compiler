package Variabler;

public class Var {
	public String typeId;
	public short intId;
	public String type;
	
}
