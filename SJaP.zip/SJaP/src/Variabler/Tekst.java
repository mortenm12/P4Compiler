package Variabler;


public class Tekst extends Var{
	public String typeVal;
}
