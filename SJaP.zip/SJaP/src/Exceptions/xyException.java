package Exceptions;

public class xyException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public xyException(String message){
		super(message);
	}
}
