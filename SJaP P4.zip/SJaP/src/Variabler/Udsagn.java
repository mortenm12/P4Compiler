package Variabler;


public class Udsagn extends Var{
	public boolean typeVal;
}
