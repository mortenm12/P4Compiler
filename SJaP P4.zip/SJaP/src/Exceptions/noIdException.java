package Exceptions;

public class noIdException extends Exception{
	public noIdException(String message)
	{
		super(message);
	}

}
