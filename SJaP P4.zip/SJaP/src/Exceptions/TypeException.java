package Exceptions;

public class TypeException extends Exception{
	public TypeException(String message)
	{
		super(message);
	}
}
