package Exceptions;

public class existingVariableException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public existingVariableException(String message){
		super(message);
	}
}
